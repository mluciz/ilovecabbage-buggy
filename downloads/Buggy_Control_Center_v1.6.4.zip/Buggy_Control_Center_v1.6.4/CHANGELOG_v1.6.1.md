# Buggy Control Center v1.6.1 — stable movement patch

Built directly from **v1.6**, not v1.7.

- Arduino: BLE motor watchdog extended from 650 ms to 1200 ms to tolerate brief BLE/SoftwareSerial stalls; after that, **both wheels actively brake**.
- Arduino: telemetry reduced from every 250 ms to every 500 ms so SoftwareSerial spends less time transmitting and more time listening to drive commands.
- Arduino: `M,0,0` now actively brakes both wheels rather than coasting.
- Windows BLE bridge: manual-drive packet interval 120 ms instead of 80 ms to reduce BLE/UART congestion. GUI stale-command timeout is 900 ms rather than 450 ms, retaining a fail-safe stop.
- Windows keyboard: require three consecutive missed physical-key checks before assuming the held key was released; real KeyRelease still acts normally.
- Original v1.6 pin assignments, routes, PWM gears, UI, diagnostics retained.

**Safety:** Test with wheels lifted and motor cutoff switch available. A right wheel that turns without commands may indicate B-channel wiring or driver failure. Do not drive on the floor until standby/brake and both wheels are reliable. Firmware cannot compensate for a failed driver channel.

**Installation:** Close older program, extract ZIP, open run.bat, and upload `arduino/BuggyController/BuggyController.ino` with motor battery disconnected. Then test with both wheels lifted. Do not use v1.7 firmware with this package.
