# v1.6.2 — 30 October 2026

Baseline: complete v1.6.1 Windows/Arduino package.

## Confirmed code-level weaknesses fixed

1. **Half-duplex UART interference:** periodic Arduino `SoftwareSerial` telemetry competed with incoming movement packets. Now send at most 1/second, after RX idle for 45 ms, while no partial packet or unread RX bytes remain; write one bounded telemetry frame.
2. **Incomplete frames:** the firmware motor command parser could remain stuck in a damaged frame; fresh M re-synchronizes. Most importantly, K emergency brake is now processed immediately even while a motor frame is incomplete.
3. **Unintended legacy movement:** arbitrary unframed F/B/L/R characters on the BLE UART were accepted as motion commands. Drive now requires framed `M,left,right\n` on BLE. USB legacy test commands remain.
4. **Unpowered idle channel:** when only one motor was commanded 0, its driver output coasted. Individual zero channels now short-brake, so the idle wheel is commanded to stop instead of freewheeling.
5. **Queued BLE state:** an old queued write could send motor/brake state after the GUI had already changed; new writer reads live state *inside* the async write lock, and rejects an obsolete urgent brake.
6. **Mixed keyboard/mouse control:** key and on-screen button sources could cancel one another. Track them independently.
7. **Brake rearming:** delayed Windows KeyRelease/KeyPress pairs could undo a brake block. Explicit ACTIVATE WASD can safely clear a stuck block when no physical movement keys are down.
8. **Diagnostics:** display/log when Arduino-command telemetry differs from a stable manual target or reports WATCHDOG BRAKE. These do not prove motor rotation.

## Verification

- 46 local regression tests pass under Xvfb, including Tk GUI and transport tests.
- The actual production Arduino sketch is compiled and executed in a C++ host test with mocked Arduino digital/PWM pins. This is **not equivalent to compiling for an Uno or running physical hardware**.
- No real HM-10, motor driver, battery or wheels were available during this update.

## Safety

Keep the motor battery disconnected for uploads and use a 10kΩ STBY-to-GND pulldown so the driver stays disabled while Uno pins are floating during reset.
