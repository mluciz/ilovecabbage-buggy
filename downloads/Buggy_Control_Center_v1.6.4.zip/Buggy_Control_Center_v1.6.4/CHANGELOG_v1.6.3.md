# v1.6.3 — Control Lab (30 October 2026)

Baseline: verified v1.6.2 archive.

## Bugs corrected

1. **Windows repeat key release:** v1.6.2 cleared its `_keyboard_pressed` entry as soon as Tk generated a KeyRelease, even when Windows was synthesizing that event for auto-repeat. v1.6.3 confirms a physical release before dropping the held key or unblocking an emergency-braked key.
2. **Misleading Braking Strength slider:** the previous slider had no impact on instant active braking and could confuse users. Removed; release/Space/Stop are explicitly active brake commands.
3. **SoftwareSerial reply collision:** Arduino's reply to the Q handshake could transmit immediately during ongoing BLE receiving. It is now deferred until no partial frame or pending input exists and the UART has been idle for at least 45 ms.
4. **GUI freeze recovery:** a prolonged frozen main loop could restart motion using stale key/route state after the BLE watchdog already braked. The GUI now latches a stop if a running drive resumes after >1.4 s without an update.
5. **Outdated diagnostics descriptions:** corrected old v1.3 upload recommendations and window titles. The on-wire H,13 protocol is intentionally unchanged.
6. **Launchers:** unnecessary pip reinstallation on every launch removed; Demo does not need BLE libraries.

## Improvements

- Bounded **Flight Recorder**: timestamped input, BLE actual payloads/write timings, Arduino PWM acknowledgements, errors and safety events; CSV export button. No sensor claims.
- **Link Health** display of last acknowledged Windows BLE write age and latency.
- **Offline Control Check** with 42 generated-input calculations; no motors used.
- **Motor Balance** (-30 to +30%) manual-only trim that *reduces* stronger-wheel command rather than ever exceeding PWM 255. Auto tracks remain untouched.
- **Motor Channel Lab** (standalone Arduino test sketch) only runs after explicit `T`, with isolated left/right forward/reverse tests and braking between segments.
- Updated GUI preview, installation and troubleshooting documentation.

## Verification

- 56 Python tests passed under simulated X display, including C++ host pin-mock tests of the actual main Arduino sketch and standalone MotorTest sketch.
- Screenshots captured from the actual Tk GUI in Demo mode, not artist mockups.
- **Not validated on physical Arduino Uno/HM-10/TB6612FNG** and not compiled with the official Arduino AVR toolchain. Nothing in these tests measures actual motor RPM, braking distance, battery voltage, or right-wheel function.
