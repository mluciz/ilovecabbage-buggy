v1.6: boot and BLE active-brake safety; direction-first braking; Windows physical key reconciliation; capped doubled PWM gear table. Hardware right-wheel issue needs electrical diagnosis.
